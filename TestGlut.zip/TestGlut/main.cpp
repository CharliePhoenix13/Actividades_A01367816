#include<windows.h>
#include<gl\glut.h>
#include<math.h>
#include<vector>
#include<iostream>
#include<cstdlib>
#include<time.h>
#include <chrono>
#include <thread>

using namespace std;
using namespace std::chrono;
using namespace std::this_thread;

int m = 8;
int n = 8;
int timeSteps = 25; //Max time of execution
int timeAux = 1;
int percentOfDirtyCells = 30;
int cleanDirection = 1; //0 for random cleaning, 1 for ZigZag cleaning
int cleanerCurrentX = 0, cleanerCurrentY = 0, c = 0;
bool leftDirection = false, rightDirection = true, upDirection = false, downDirection = true;
vector <vector <int> > chessboardLogical;

void init(){
    // For displaying the window color
    glClearColor(1, 1, 1, 0);
    // Choosing the type of projection
    glMatrixMode(GL_PROJECTION);
    // for setting the transformation which here is 2D
    gluOrtho2D(0, 800, 0,600);
}

void drawCircle(float cx, float cy, float r, int num_segments) {
    glBegin(GL_LINE_LOOP);
    for (int ii = 0; ii < num_segments; ii++)   {
        float theta = 2.0f * 3.1415926f * float(ii) / float(num_segments);//get the current angle
        float x = r * cosf(theta);//calculate the x component
        float y = r * sinf(theta);//calculate the y component
        glVertex2f(x + cx, y + cy);//output vertex
    }
    glEnd();
}

void drawSquare(GLint x1, GLint y1, GLint x2, GLint y2, GLint x3, GLint y3, GLint x4, GLint y4){
    // if color is 0 then draw white box
    switch (c){
        case 0:
            glColor3f(0, 0, 0); // Draw empty square
            glBegin(GL_LINE_STRIP);
            glVertex2i(x1, y1);
            glVertex2i(x2, y2);
            glVertex2i(x3, y3);
            glVertex2i(x4, y4);
            glEnd();
            break;
        case 1:
            glColor3f(255, 0, 0); // Draw dirty square (red color)
            glBegin(GL_POLYGON);
            glVertex2i(x1, y1);
            glVertex2i(x2, y2);
            glVertex2i(x3, y3);
            glVertex2i(x4, y4);
            glEnd();
            break;
        case 2:
            glColor3f(0, 0, 255); // Draw VACCUM square (blue color)
            glBegin(GL_POLYGON);
            glVertex2i(x1, y1);
            glVertex2i(x2, y2);
            glVertex2i(x3, y3);
            glVertex2i(x4, y4);
            glEnd();
            break;
    }
    //glutPostRedisplay();
    //glBegin(GL_POLYGON);

}

void chessboard(){
    glClear(GL_COLOR_BUFFER_BIT); // Clear display window
    GLint x, y;
    int sizeM = 800 / m;
    int sizeN = 600 / n;

    for (x = 0; x < 800; x += sizeM){
        for (y = 0; y < 600; y += sizeN){
            c = chessboardLogical[(n - 1 - y/sizeN)][(x/sizeM)];
            drawSquare(x, y + sizeN, x + sizeM, y + sizeN, x +sizeM, y, x, y);
        }
    }

    // Process all OpenGL routine s as quickly as possible
    glFlush();
}

void setChessBoard(){
    vector <int> temporalVector;
    int i, j, dirtyCell, posX, posY;
    int numberOfDirtyCells = ((m*n) * percentOfDirtyCells) / 100;
    for(i = 0; i < m; i++){
        for(j = 0; j < n; j++){
            temporalVector.push_back(0);
        }
        chessboardLogical.push_back(temporalVector);
        temporalVector.clear();
    }

    chessboardLogical[0][0] = 2;
    i = 0;
    while(i <= numberOfDirtyCells){
        dirtyCell = (rand() % (m*n)) + 1;
        posX = dirtyCell / m;
        posY = dirtyCell % n;
        if(chessboardLogical[posY][posX] == 0){
            chessboardLogical[posY][posX] = 1;
            i++;
        }
    }


}

void printChessBoardLogical() {
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            cout << chessboardLogical[i][j];
        }
    cout << "\n";
    }
}

void moveLeft(){
    if((cleanerCurrentX - 1) >= 0){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentX--;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}

void moveRight(){
    if((cleanerCurrentX + 1) < m){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentX++;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}

void moveUp(){
    if((cleanerCurrentY - 1) >= 0){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentY--;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}

void moveDown(){
    if((cleanerCurrentY + 1) < n){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentY++;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}

void moveUpLeft(){
    if(((cleanerCurrentX - 1) >= 0) && ((cleanerCurrentY - 1) >= 0)){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentX--;
        cleanerCurrentY--;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}

void moveUpRight(){
    if(((cleanerCurrentX + 1) < m) && ((cleanerCurrentY - 1) >= 0)){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentX++;
        cleanerCurrentY--;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}

void moveDownLeft(){
    if(((cleanerCurrentX - 1) >= 0) && (cleanerCurrentY + 1 < n)){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentX--;
        cleanerCurrentY++;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}

void moveDownRight(){
    if(((cleanerCurrentX + 1) < m) && (cleanerCurrentY + 1 < n)){
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 0;
        cleanerCurrentX++;
        cleanerCurrentY++;
        chessboardLogical[cleanerCurrentY][cleanerCurrentX] = 2;
    }
}


void moveRandom(){
    int direction = (rand() % 8) + 1;
    switch(direction) {
    case 1:
        moveLeft();
        cout <<"Left\n\n";
        break;
    case 2:
        moveRight();
        cout <<"Right\n\n";
        break;
    case 3:
        moveUpLeft();
        cout <<"Up Left\n\n";
        break;
    case 4:
        moveUpRight();
        cout <<"Up Right\n\n";
        break;
    case 5:
        moveUp();
        cout <<"Up\n\n";
        break;
    case 6:
        moveDown();
        cout <<"Down\n\n";
        break;
    case 7:
        moveDownLeft();
        cout <<"Down Left\n\n";
        break;
    case 8:
        moveDownRight();
        cout <<"Down Right\n\n";
        break;
    }
}

void moveZigZag(){
    cout << "\n\n";
    if((cleanerCurrentX + 1 >= m) && rightDirection){
        leftDirection = true;
        rightDirection = false;
        moveDown();
    } else if((cleanerCurrentX - 1 < 0) && leftDirection){
        leftDirection = false;
        rightDirection = true;
        moveDown();
    } else if(leftDirection && downDirection){
        moveDownLeft();
        downDirection = false;
        upDirection = true;
    } else if(leftDirection && upDirection){
        moveUpLeft();
        downDirection = true;
        upDirection = false;
    } else if(rightDirection && downDirection){
        moveDownRight();
        downDirection = false;
        upDirection = true;
    } else if(rightDirection && upDirection){
        moveUpRight();
        downDirection = true;
        upDirection = false;
    }
}

static void idle(void)
{
    if(timeAux <= timeSteps){
        if(cleanDirection == 0){
            moveRandom();
        } else{
            moveZigZag();
        }
        printChessBoardLogical();
        glutPostRedisplay();
        timeAux++;
        sleep_for(nanoseconds(10));
        sleep_until(system_clock::now() + seconds(1));
    }
}

int main(int agrc, char ** argv){
    srand(time(0));
    setChessBoard();
    // Initialize GLUT
    glutInit(&agrc, argv);
    // Set display mode
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    // Set top - left display window position.
    glutInitWindowPosition(100, 100);
    // Set display window width and height
    glutInitWindowSize(800, 600);
    // Create display window with the given title
    glutCreateWindow("");
    // Execute initialization procedure
    init();
    // Send graphics to display window
    glutDisplayFunc(chessboard);
    // Display everything and wait.
    glutIdleFunc(idle);

    glutMainLoop();
}
